<?php
/*
	Template Name: Homepage & Blocks (DPL home)
*/

get_header();


?>

<style type="text/css">
li.widget { background:url('http://derbynecklibrary.org/main/wp-content/themes/smart-mag-child/images/widget-header-bg.png') 0 9px no-repeat; float:left; width:100%; margin-top:15px;}
.main { margin-top: 0; }
.main .row { padding-top:0; }
.main .sidebar { margin-top:11px;}
.main .sidebar h3.widgettitle, h3.widgettitle{ color:#437a45; }

@media screen and (max-width: 800px) {
li#bunyad-blocks-widget-2 { display:none; }
.sidebar ul { float:left; width:97%;}
}
</style>
<div class="main wrap cf">

	<div class="row">
		<div class="col-8 main-content">
			         <?php if (Bunyad::posts()->meta('featured_slider')):
	get_template_part('partial-sliders');
endif; ?>
			<?php if (have_posts()): the_post(); endif; // load the page ?>

			<div id="post-<?php the_ID(); ?>" <?php post_class('page-content'); ?>>

			<?php if (Bunyad::posts()->meta('page_title') != 'no'): ?>
			
				<header class="post-header">				
					
				<?php if (has_post_thumbnail()): ?>
					<div class="featured">
						<a href="<?php $url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full'); echo $url[0]; ?>" title="<?php the_title_attribute(); ?>">
						
						<?php if ((!in_the_loop() && Bunyad::posts()->meta('layout_style') == 'full') OR Bunyad::core()->get_sidebar() == 'none'): // largest images - no sidebar? ?>
						
							<?php the_post_thumbnail('main-full', array('title' => strip_tags(get_the_title()))); ?>
						
						<?php else: ?>
							
							<?php the_post_thumbnail('main-slider', array('title' => strip_tags(get_the_title()))); ?>
							
						<?php endif; ?>
						
						</a>
					</div>
				<?php endif; ?>
				
					<h1 class="main-heading">
						<?php the_title(); ?>
					</h1>
				</header><!-- .post-header -->
				
			<?php endif; ?>
		
						
			<?php Bunyad::posts()->the_content(); ?>


				<div id="column1-left">	
		<div class="left-side-header"><h5>Hours</h5></div>		<?php $post_id = 202;
global $post;
$post = &get_post($post_id);
setup_postdata( $post );

the_content();
wp_reset_postdata( $post ); ?>


<div class="left-side-header"><h5>Quick Links</h5></div>
<?php wp_nav_menu( array('menu' => 'Quick Links' )); ?>	
                  
                      
      	<div class="left-side-header"><h5>Newsletter</h5></div>   
               <?php
global $post;
$args = array( 'numberposts' => 1, 'category' => 22 );
$myposts = get_posts( $args );
foreach( $myposts as $post ) :  setup_postdata($post); ?>
<?php $key="Newsletter-link";

$post_meta = get_post_meta($post->ID, $key, true);

if(!empty($post_meta)){

?>
<div class="newsletter-link"><a href="<?php ; echo $post_meta; ?>" title="<?php the_title_attribute(); ?>" target="_blank">View the Newsletter <br/>in PDF Format</a></div>

<?php } ?> 
<?php endforeach; wp_reset_postdata(); ?>   
               
       

	<div class="left-side-header"><h5>Virtual Tour</h5></div>
            	       
          <a href="https://www.youtube.com/watch?v=oZdTVu7Ljr4" target="_blank"><img src="http://derbynecklibrary.org/main/wp-content/themes/smart-mag-child/images/virtual-tour.jpg" style="margin-top:6px;" /> </a>
                  
   <div class="left-side-header"><h5>Community Links</h5></div>
<?php wp_nav_menu( array('menu' => 'Community Links' )); ?>	             
                  
                  
                  
                  
                  </div>


                <div id="column1-right">
				<!-- news -->
<h5 style="margin-top:0;"><?php echo get_cat_name(5);?></h5>
             
			 <?php
global $post;
$args = array( 'numberposts' => 2, 'category' => 5 );
$myposts = get_posts( $args );
foreach( $myposts as $post ) :  setup_postdata($post); ?>
 <div class="post1">

    <a href="<?php the_permalink() ?>" ><?php the_post_thumbnail(array(258,210)); ?></a><br />
    <h3 class="home-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<?php the_content(); ?>  </div>
<?php endforeach; wp_reset_postdata(); ?>   
               
               <div style="clear:both;"> </div>
    <h5>New and Popular Books and Ebooks in the Library</h5>  
            
         
 
<div id="book-widget-wrap">
         
     <div class="book-widget">
     <script type="text/javascript"
src="http://wowbrary.org/widgetslider.aspx?library=1642&provideraccount=bibna&width=550&motion=one-at-a-time&imagesize=M&buttonstyle=modern&titlestyle=font-family%3a+%27PT+Serif%27%3b+color%3a%23303030">
</script>
</div>
           </div>    
           
               <div style="clear:both;"> </div>
    <h5>Featured Databases</h5>  
        
     <div>
    <?php
global $post;
$args = array( 'numberposts' => 4, 'category' => 18 );
$myposts = get_posts( $args );
foreach( $myposts as $post ) :  setup_postdata($post); ?>
 <div class="database-wrap" style="float:left; display:block;">

 	         <?php $key="Databases-link";

$post_meta = get_post_meta($post->ID, $key, true);

if(!empty($post_meta)){

?>
<div class="database-title"><a href="<?php ; echo $post_meta; ?>" title="<?php the_title_attribute(); ?>" target="_blank"><?php the_title(); ?></a></div>
<div class="database-thumb"><a href="<?php ; echo $post_meta; ?>" target="_blank"><?php the_post_thumbnail(array(240,200)); ?></a></div>

<div class="database-content"><?php the_content(); ?></div>
<?php } ?> 
  </div>
<?php endforeach; wp_reset_postdata(); ?>   
               </div>   
               
                </div>
           
			</div>
			
		</div>
		
		<?php Bunyad::core()->theme_sidebar(); ?>
        
        <aside class="col-4 sidebar">
        <ul>
        <div id="social-media">
        <h3 class="widgettitle">Follow Us</h3>
        <div style="clear:both;"></div>
        <div id="facebook"><div class="social-media-icon facebook-icon"><a href="https://www.facebook.com/Derby-Neck-Library-52838817108" target="_blank">&#xf09a;</a></div> <div class="sm-title"><a href="https://www.facebook.com/Derby-Neck-Library-52838817108"  target="_blank">Facebook</a></div>
</div>
<div id="twitter"><div class="social-media-icon twitter-icon"><a href="http://twitter.com/derbynecklibrar" target="_blank">&#xf099;</a></div><div class="sm-title"><a href="http://twitter.com/derbynecklibrar" target="_blank">Twitter</a></div>
</div>
<div id="pinterest"><div class="social-media-icon pinterest-icon"><a href="https://www.pinterest.com/derbyneck/" target="_blank">&#xf231;</a></div> <div class="sm-title"><a href="https://www.pinterest.com/derbyneck/"  target="_blank">Pinterest</a></div>
</div>
<div id="youtube"><div class="social-media-icon youtube-icon"><a href="https://www.youtube.com/user/TheDerbyNeckLibrary/" target="_blank">&#xf167;</a></div> <div class="sm-title"><a href="https://www.youtube.com/user/TheDerbyNeckLibrary/"  target="_blank">Youtube</a></div>
</div>

</div>

        <div id="upcoming-events">
        <h3 class="widgettitle">Upcoming Events</h3>
        <div class="css-events-list">
            <?php echo do_shortcode('[events_list limit="6"]
									<div class="event-list-post">
									<div class="event-list-thumb"><a href="#_EVENTURL">#_EVENTIMAGE{70,0}</a></div>
 <div class="event-list-content"><h2><a href="#_EVENTURL">#_EVENTNAME</a></h2> 
									 <h4 class="la-date">#l, #_EVENTDATES</h4>
									 <h4 class="le-temps">#_12HSTARTTIME</h4>
									  </div>
									  </div>
									  <div style="clear:both;"></div>
									 [/events_list]'); ?>	
		</div>
        </div>
        <div id="calendar-widget">
        <h3 class="widgettitle">Calendar</h3>
        <?php echo do_shortcode('[events_calendar]'); ?>
        </div>
        </ul>
        </aside>
		
	</div> <!-- .row -->
</div> <!-- .main -->

<?php get_footer(); ?>
