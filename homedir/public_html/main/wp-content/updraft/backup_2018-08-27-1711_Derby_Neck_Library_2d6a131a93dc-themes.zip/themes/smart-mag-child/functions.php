<?php

	

		
		add_image_size('image-grid-loop-DNL', 190, 0, false); // size for grid overlay listing


		add_image_size('image-post-loop-DNL',400, 0, false); // size for grid overlay listing
		
		
			// register dynamic sidebar
		register_sidebar(array(
			'name' => __('Homepage Sidebar', 'bunyad'),
			'id'   => 'homepage-sidebar',
			'description' => __('Widgets in this area will be shown in the homepage sidebar.', 'bunyad'),
			'before_title' => '<h3 class="widgettitle">',
			'after_title'  => '</h3>',
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
		));
		
		
			// register dynamic sidebar
		register_sidebar(array(
			'name' => __('Teen Space Sidebar', 'bunyad'),
			'id'   => 'teen-space-sidebar',
			'description' => __('DNL Teen Space', 'bunyad'),
			'before_title' => '<h3 class="widgettitle dnl-teen">',
			'after_title'  => '</h3>',
			'before_widget' => '<div id="%1$s" class="widget %2$s dnl-teen">',
			'after_widget' => '</div>',
		));
		
			// register dynamic sidebar
		register_sidebar(array(
			'name' => __('Childrens Sidebar', 'bunyad'),
			'id'   => 'childrens-sidebar',
			'description' => __('DNL Childrens Corner', 'bunyad'),
			'before_title' => '<h3 class="widgettitle dnl-teen">',
			'after_title'  => '</h3>',
			'before_widget' => '<div id="%1$s" class="widget %2$s dnl-childrens">',
			'after_widget' => '</div>',
		));
		
		register_nav_menu('childrens', __('Childrens Navigation', 'bunyad'));
		register_nav_menu('teens', __('Teens Navigation', 'bunyad'));
		
		add_filter('single_template', 'single_template_terms');
function single_template_terms($template) {
    foreach( (array) wp_get_object_terms(get_the_ID(), get_taxonomies(array('public' => true, '_builtin' => false))) as $term ) {
        if ( file_exists(TEMPLATEPATH . "/single-{$term->slug}.php") )
            return TEMPLATEPATH . "/single-{$term->slug}.php";
    }
    return $template;
}

add_filter( 'single_template', 'themeslug_single_template' );

/**
 * Add category considerations to the templates WordPress uses for single posts
 *
 * @global obj $post The default WordPress post object. Used so we have an ID for get_post_type()
 * @param string $template The currently located template from get_single_template()
 * @return string The new locate_template() result
 */
function themeslug_single_template( $template ) {
    global $post;

    $categories = get_the_category();

    if ( ! $categories )
        return $template; // no need to continue if there are no categories

    $post_type = get_post_type( $post->ID );

    $templates = array();

    foreach ( $categories as $category ) {

        $templates[] = "single-{$post_type}-{$category->slug}.php";

        $templates[] = "single-{$post_type}-{$category->term_id}.php";
    }

    // remember the default templates

    $templates[] = "single-{$post_type}.php";

    $templates[] = 'single.php';

    $templates[] = 'index.php';

    /**
     * Let WordPress figure out if the templates exist or not.
     *
     * @see http://codex.wordpress.org/Function_Reference/locate_template
     */
    return locate_template( $templates );
}