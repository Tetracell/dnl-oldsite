<?php

/**
 Template Name: Teens Home
 */


get_header('teens');



?>

<style type="text/css">

#upcoming-events { padding: 3%; width:94%; text-align:left; }
</style>

<div class="main wrap cf">

	<div class="row">
		<div class="col-8 main-content" style="padding-right:0;">
			
			<?php if (have_posts()): the_post(); endif; // load the page ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		
			<div class="post-content" style="padding:0 2%;">			
				
				<?php Bunyad::posts()->the_content(); ?>
				
			</div>

			</article>


<div id="upcoming-events">

            <div class="css-events-list"><h1 class="title-post">Teen Events</h1>
            <?php echo do_shortcode('[events_list category="20" format=""]
									<div class="event-list-post">
									<div class="event-list-thumb"><a href="#_EVENTURL">#_EVENTIMAGE</a></div>
									<div class="event-list-content">
 <h2><a href="#_EVENTURL">#_EVENTNAME </a></h2>
									 <h4 class="la-date">#l, #_EVENTDATES, #Y</h4>
									 <h4 class="le-temps">#_EVENTTIMES</h4>
									  #_EVENTNOTES
									  </div></div><div style="clear:both;"></div>
									 [/events_list]'); ?>	
		
        </div>
        <div style="clear:both;"></div>
        <div class="css-events-list" style="padding-top:40px;">  <h1 class="title-post">Repeating Teen Programs</h1>
             <?php echo do_shortcode('[events_list category="21" recurring="1" format=""]
									<div class="event-list-post">
									<div class="event-list-thumb">#_EVENTIMAGE</div>
									<div class="event-list-content">
									  <h2>#_EVENTNAME</h2>
									  <h4 class="la-date">#_ATT{days}</h4>
							<h4 class="la-date">#M. #j#S, #Y  #@_{ \u\n\t\i\l M. jS, Y } </h4>
									<h4 class="le-temps">#_EVENTTIMES</h4>
									#_EVENTNOTES<br />
								</div></div><div style="clear:both;"></div>
						
									 [/events_list]'); ?>	
								    	     
                                        
                                        
                                        	</div>
        
            </div>
		</div>
		
		<?php Bunyad::core()->theme_sidebar(); ?>
		
	</div> <!-- .row -->
</div> <!-- .main -->

<?php get_footer(); ?>
