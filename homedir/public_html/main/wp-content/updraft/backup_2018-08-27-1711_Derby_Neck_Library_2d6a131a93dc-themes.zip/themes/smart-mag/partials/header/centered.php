<?php
/**
 * Partial: Centered Header
 */
?>

		<header class="centered">
		
			<div class="title">
			
				<?php get_template_part('partials/header/logo'); ?>
			
			</div>
			
		</header>