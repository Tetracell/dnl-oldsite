<?php

/**
 Template Name: Events (Teens)
 */


get_header('teens');


if (Bunyad::posts()->meta('featured_slider')):
	get_template_part('partial-sliders');
endif;

?>

<div class="main wrap cf">

	<div class="row">
		<div class="col-8 main-content">
			
			<?php if (have_posts()): the_post(); endif; // load the page ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<?php if (Bunyad::posts()->meta('page_title') != 'no'): ?>
			
				<header class="post-header">				
					
				<?php if (has_post_thumbnail() && !Bunyad::posts()->meta('featured_disable')): ?>
					<div class="featured">
						<a href="<?php $url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full'); echo $url[0]; ?>" title="<?php the_title_attribute(); ?>">
						
						<?php if ((!in_the_loop() && Bunyad::posts()->meta('layout_style') == 'full') OR Bunyad::core()->get_sidebar() == 'none'): // largest images - no sidebar? ?>
						
							<?php the_post_thumbnail('medium', array('title' => strip_tags(get_the_title()))); ?>
						
						<?php else: ?>
							
							<?php the_post_thumbnail('medium'); ?>
							
						<?php endif; ?>
						
						</a>
					</div>
				<?php endif; ?>
				
					<h1 class="main-heading" style="margin-bottom:15px;">
						<?php the_title(); ?>
					</h1>
				</header><!-- .post-header -->
				
			<?php endif; ?>
		
			<div class="post-content">			
				
				<?php Bunyad::posts()->the_content(); ?>
				  <div class="css-events">
            
                  <?php echo do_shortcode('[events_list category="20" format=""]
										  <div class="event-list-post">
									<div class="event-list-thumb"><a href="#_EVENTURL">#_EVENTIMAGE</a></div>
									<div class="event-list-content">
									  <h2><a href="#_EVENTURL">#_EVENTNAME</a> </h2>
				<h4 class="la-date"><span class="le-jour">#l,</span> #_EVENTDATES<BR />#_EVENTTIMES</h4>
									#_EVENTEXCERPT <span class="read-more"><a href="#_EVENTURL">Read more...</a></span>
											</div></div><div style="clear:both;"></div>[/events_list]'); ?>	
		   </div>
           <div style="clear:both;"></div>
          <h2 style="margin-bottom:15px; font-weight:bold;">Repeating  Events</h2>
           <div class="css-events">
             <?php echo do_shortcode('[events_list category="21" recurring="1" format=""]
									<div class="event-list-post">
									<div class="event-list-thumb">#_EVENTIMAGE</div>
									<div class="event-list-content">
									  <h2 style="color:#c93439;">#_EVENTNAME</h2>
									  <h4 class="la-date" style="margin-bottom:0;">#_ATT{days}</h4>
					
									<h4 class="le-temps">#_EVENTTIMES</h4>
									#_EVENTNOTES </div></div><div style="clear:both;"></div>
						
									 [/events_list]'); ?>	
           
            </div>
			</div>

			</article>
			
		</div>
		
		<?php Bunyad::core()->theme_sidebar(); ?>
		
	</div> <!-- .row -->
</div> <!-- .main -->

<?php get_footer(); ?>
