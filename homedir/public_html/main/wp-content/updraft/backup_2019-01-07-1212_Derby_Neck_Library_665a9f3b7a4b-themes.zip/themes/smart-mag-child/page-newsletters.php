<?php

/**
 Template Name: Newsletters
 */


get_header();



?>

<div class="main wrap cf">

	<div class="row">
		<div class="col-8 main-content">
			<h1 class="main-heading">Newsletters</h1>
            <div class="post-content">
            <ul>
			<?php
global $post;
$args = array( 'category' => 22 );
$myposts = get_posts( $args );
foreach( $myposts as $post ) :  setup_postdata($post); ?>
<?php $key="Newsletter-link";

$post_meta = get_post_meta($post->ID, $key, true);

if(!empty($post_meta)){

?>
<li class="newsletter-list"><a href="<?php ; echo $post_meta; ?>" title="<?php the_title_attribute(); ?>" target="_blank"><?php the_title(); ?></a></li>

<?php } ?> 
<?php endforeach; wp_reset_postdata(); ?> 
</ul> 
</div>
		</div>
		
		<?php Bunyad::core()->theme_sidebar(); ?>
		
	</div> <!-- .row -->
</div> <!-- .main -->

<?php get_footer(); ?>
