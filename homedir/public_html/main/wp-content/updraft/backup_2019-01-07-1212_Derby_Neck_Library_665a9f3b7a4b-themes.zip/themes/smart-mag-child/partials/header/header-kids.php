<?php
/**
 * Partial: Default Header
 */
?>

		<header>
        
		<div class="right">
				
				<div id="header-search">
                <h5>Search the Children's Catalog</h5>
            <form style="display:inline;" id="form1" action="http://dbneck.biblio.org/eg/kpac/results" method="get">

        <div class="searchbar">

        

           <div class="selectbar"> <select name="qtype" id="qtype" aria-label="Select query type:">

        <option value="keyword" selected="selected">Keyword</option>

        <option value="title">Title</option>

        <option value="author">Author</option>

        <option value="subject">Subject</option>

        <option value="series">Series</option>

    </select>

    </div>

            <input type="text" id="search_box" name="query" aria-label="Enter search query:" value="" placeholder="Find books, movies, and more" >





        <input id="search-submit-go" type="submit" value="Search" alt="Search" class="opac-button" onclick="setTimeout(function(){$(&quot;search-submit-spinner&quot;).className=&quot;&quot;; $(&quot;search-submit-go&quot;).className=&quot;hidden&quot;}, 2000)">



    </div>

        </form>
        </div>
				
			</div>
			<div class="title">
			
			
				
		<a href="http://derbynecklibrary.org/main/childrens" title="Derby Neck Library Children's Corner" rel="home">
		
							
				<img src="http://derbynecklibrary.org/main/wp-content/themes/smart-mag-child/images/kids-logo.png" class="logo-image" alt="Derby Neck Library Children's Corner">
					 
						
		</a>			
			
			
			</div>
			
			
		</header>