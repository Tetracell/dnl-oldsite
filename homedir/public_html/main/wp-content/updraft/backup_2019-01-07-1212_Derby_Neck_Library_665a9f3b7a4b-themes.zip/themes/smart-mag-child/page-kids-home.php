<?php

/**
 Template Name: Children's Home
 */


get_header('kids');



?>

<style type="text/css">
.main-featured { padding: 0 0 0 20px; margin:0 auto; text-align:center; float:none; width:auto; display:block;}
.main-featured .slider { display:inline-block; float:none; }
#upcoming-events { padding: 3%; width:94%; text-align:left; }
@media screen and (max-width: 600px) { 
.post-content img { max-width:160px; height:auto; }
.post-content .wp-caption { max-width:160px!important; }
}
</style>

<div class="main wrap cf">

	<div class="row">
		<div class="col-8 main-content" style="padding-right:0;">
			
			<?php if (have_posts()): the_post(); endif; // load the page ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		
			<div class="post-content" style="padding:0 2%;">			
				
				<?php Bunyad::posts()->the_content(); ?>
				
			</div>

			</article>
	
<div id="upcoming-events">
            
            <div class="css-events-list"><h1 class="title-post">Children's Events</h1>
            <?php echo do_shortcode('[events_list category="11" format=""]
									<div class="event-list-post">
									<div class="event-list-thumb"><a href="#_EVENTURL">#_EVENTIMAGE</a></div>
									<div class="event-list-content">
 <h2><a href="#_EVENTURL">#_EVENTNAME </a></h2>
									 <h4 class="la-date">#l, #_EVENTDATES, #Y</h4>
									 <h4 class="le-temps">#_EVENTTIMES</h4>
									  #_EVENTNOTES
									 </div></div><div style="clear:both;"></div>
									 [/events_list]'); ?>	
		
        </div>
        <div style="clear:both;"></div>
        <div class="css-events-list" style="padding-top:40px;">  <h1 class="title-post">Repeating Children's Programs</h1>
             <?php echo do_shortcode('[events_list category="13" recurring="1" format=""]
									<div class="event-list-post">
									<div class="event-list-thumb">#_EVENTIMAGE</div>
									<div class="event-list-content">
									  <h2>#_EVENTNAME</h2>
									  <h4 class="la-date">#_ATT{days}</h4>
									<h4 class="le-temps">#_EVENTTIMES</h4>
									#_EVENTNOTES<br />
								</div></div><div style="clear:both;"></div>
						
									 [/events_list]'); ?>	
								    	     
                                        
                                        
                                        	</div>
        
            </div>
		</div>
		
		<?php Bunyad::core()->theme_sidebar(); ?>
		
	</div> <!-- .row -->
</div> <!-- .main -->

<?php get_footer(); ?>
