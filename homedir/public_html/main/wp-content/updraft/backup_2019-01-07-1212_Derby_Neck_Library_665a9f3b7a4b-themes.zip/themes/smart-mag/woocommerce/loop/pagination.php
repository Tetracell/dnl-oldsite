	
	<div class="main-pagination">
		<?php echo Bunyad::posts()->paginate(); ?>
	</div>