window.jQuery(function ($) {
	/**
	 * Extra JS for the Nivo Dark theme
	 */

	$('.ms-theme-nivo-dark .slider-wrapper').each(function () {
		$(this).removeClass('theme-default');
	});
});