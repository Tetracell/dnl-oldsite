=== Page Builder by SiteOrigin - Modified by Theme-Sphere.com ===
Contributors: gpriday
Tags: page builder, responsive, widget, widgets, builder, page, admin, gallery, content, cms, pages, post, css, layout, grid
Requires at least: 3.5
Tested up to: 3.6
Stable tag: trunk
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Donate link: http://siteorigin.com/page-builder/#donate

Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.

== Description ==

This is forked version of SiteOrigin's PageBuilder originally created by gpriday and adapted by Theme-Sphere.com.