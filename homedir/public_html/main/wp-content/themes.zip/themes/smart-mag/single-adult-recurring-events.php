<?php 


$template = Bunyad::posts()->meta('layout_template');

if (!$template OR strstr($template, 'classic')) {
	$template = 'classic';
}

if ($template != 'classic') {
	Bunyad::core()->add_body_class('post-layout-' . $template);
}

?>

<?php get_header(); ?>

<div class="main wrap cf">

	<?php if ($template != 'classic'): // not the default layout? ?>
		
		<?php get_template_part('partials/single/layout-' . $template); ?>
	
	<?php else: ?>
	
	<div class="row">
		<div class="col-8 main-content">
		
			<?php while (have_posts()) : the_post(); ?>
	
				<?php 
					
					$panels = get_post_meta(get_the_ID(), 'panels_data', true);
					
					if (!empty($panels) && !empty($panels['grid'])):
						
						get_template_part('content', 'builder');
					
					else:
					
						get_template_part('content', 'single');
						
					endif; 
				?>
	
				
	
			<?php endwhile; // end of the loop. ?>
	
		</div>
		
		<?php Bunyad::core()->theme_sidebar(); ?>
	
	</div> <!-- .row -->
		
	<?php endif; ?>

</div> <!-- .main -->

<?php get_footer(); ?>