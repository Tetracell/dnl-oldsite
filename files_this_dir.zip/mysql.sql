-- cPanel mysql backup
GRANT USAGE ON *.* TO 'dnladmin'@'50.87.144.174' IDENTIFIED BY PASSWORD '*A767BC8468F2ED2330BB29B9A8BEE0B4309488F5';
GRANT ALL PRIVILEGES ON `dnladmin\_wp`.* TO 'dnladmin'@'50.87.144.174';
GRANT ALL PRIVILEGES ON `dnladmin\_wrdp1`.* TO 'dnladmin'@'50.87.144.174';
GRANT USAGE ON *.* TO 'dnladmin'@'gator3139.hostgator.com' IDENTIFIED BY PASSWORD '*A767BC8468F2ED2330BB29B9A8BEE0B4309488F5';
GRANT ALL PRIVILEGES ON `dnladmin\_wp`.* TO 'dnladmin'@'gator3139.hostgator.com';
GRANT ALL PRIVILEGES ON `dnladmin\_wrdp1`.* TO 'dnladmin'@'gator3139.hostgator.com';
GRANT USAGE ON *.* TO 'dnladmin'@'localhost' IDENTIFIED BY PASSWORD '*A767BC8468F2ED2330BB29B9A8BEE0B4309488F5';
GRANT ALL PRIVILEGES ON `dnladmin\_wp`.* TO 'dnladmin'@'localhost';
GRANT ALL PRIVILEGES ON `dnladmin\_wrdp1`.* TO 'dnladmin'@'localhost';
GRANT USAGE ON *.* TO 'dnladmin_wp'@'localhost' IDENTIFIED BY PASSWORD '*70E1C076E58C487B540723911818AABAE973EEAA';
GRANT ALL PRIVILEGES ON `dnladmin\_wp`.* TO 'dnladmin_wp'@'localhost';
GRANT USAGE ON *.* TO 'dnladmin_wrdp1'@'localhost' IDENTIFIED BY PASSWORD '*5A9CF152A499121E382DE1B31B52FB04AEF5F1F5';
GRANT ALL PRIVILEGES ON `dnladmin\_wrdp1`.* TO 'dnladmin_wrdp1'@'localhost';
